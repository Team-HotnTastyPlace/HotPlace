package register.spring;

public class IdPasswordMatchingException extends RuntimeException{

}
