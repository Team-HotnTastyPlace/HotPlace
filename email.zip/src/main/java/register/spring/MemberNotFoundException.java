package register.spring;

public class MemberNotFoundException extends RuntimeException{

}
