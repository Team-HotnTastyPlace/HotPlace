package register.spring;

import java.util.Date;

public class MemberRegisterService {
	private MemberDao memberDao;
	
	public MemberRegisterService(MemberDao memberDao) {
		this.memberDao = memberDao;
	}
	
	public void regist(RegisterRequest req) {
		Member member = (Member) memberDao.selectByName(req.getName());
		if(member != null) {
			throw new AlreadyExistingMemberException();
		}
		Member newMember = new Member(req.getEmail(),
									req.getPassword(),
									req.getName(),
									new Date());
		memberDao.insert(newMember);
	}
}
