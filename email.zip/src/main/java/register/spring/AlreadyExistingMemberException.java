package register.spring;

public class AlreadyExistingMemberException extends RuntimeException{
	public AlreadyExistingMemberException() {}
}
