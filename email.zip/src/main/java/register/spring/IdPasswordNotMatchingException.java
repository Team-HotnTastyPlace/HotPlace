package register.spring;

public class IdPasswordNotMatchingException extends RuntimeException{

}
